var numSecreto = parseInt(Math.random() * 501);
var tentativas = 10;
var acertou = false;

while(tentativas > 0 && !acertou) {
  var chute = prompt(`Digite um número  entre 0 e 500. Você tem ${tentativas} tentativas.`)
  tentativas --;
  if (chute == numSecreto) {
     alert('Acertou')
  }
  else if (chute > numSecreto) {
    alert('Errou... O número é menor do que ' + chute)
  }
  else if (chute < numSecreto){
    alert('Errou... o numéro é maior do que ' + chute)
}
}

if (acertou) {
  alert('Parabéns! Você acertou o número secreto!');
} else {
  alert(`Você não conseguiu acertar o número secreto. O número era ${numSecreto}.`);
}