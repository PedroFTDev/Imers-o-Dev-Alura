var bitValue = 30;
var quoteBit = 11810911;
var realValue = bitValue * quoteBit;

realValue = realValue.toFixed(2);
alert("R$" + realValue);
