var name = "Peter";
var euroValue = 50;
var quoteEuro = 5.54;
var realValue = euroValue * quoteEuro;

realValue = realValue.toFixed(2);
alert("Hello " + name + " the amount to be paid will be R$" + realValue);
