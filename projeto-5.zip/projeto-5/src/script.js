var listaNome = []
var listaFilme = []
var listaTrailer = []

function adicionarFilme() { 
  var nome = document.getElementById('nome').value
  var filme = document.getElementById('filme').value
  var trailer = document.getElementById('trailer').value
  
  var filmeTotal = '<a href=' + trailer + ' target= _blank >' + '<img src=' + filme + '></a><br>' + '<p class=page-subtitle>' + nome + '</p>'
  
  var extensao =  filme.split(".").pop();
  
  if(filme == '' || trailer == '' || nome == ''){
    alert("Por favor, preencha todos os campos corretamente."); 
    return; 
  }else if(extensao != 'jpg'){
    alert('Imagem adicionada não é do formato .jpg')
    return;
  }else{
    listaNome.push(nome)
    listaFilme.push(filme)
    listaTrailer.push(trailer)
  }

  
  listaFilmes.innerHTML = listaFilmes.innerHTML + filmeTotal

  document.getElementById('nome').value = ''
  document.getElementById('filme').value = ''
  document.getElementById('trailer').value = ''
 
   //console.log(listaFilme)
}

function apagarFilme(){
  listaNome.length = 0
  listaFilme.length = 0
  listaTrailer.length = 0
  
  var apagar = document.getElementById('listaFilmes')
  apagar.innerHTML = ''
  
  //console.log(listaFilme)
}