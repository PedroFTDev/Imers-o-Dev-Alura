var jogadores = [];

var elementoTabela = document.getElementById("tabelaJogadores");

exibirNaTela();

function exibirNaTela() {
  elementoTabela.innerHTML = "";
  for (var index = 0; index < jogadores.length; index++)
    elementoTabela.innerHTML += `
 <tr>
        <td>${jogadores[index].nome}</td>
        <td>${jogadores[index].vitoria}</td>
        <td>${jogadores[index].empate}</td>
        <td>${jogadores[index].derrotas}</td>
        <td>${jogadores[index].pontos}</td>
        <td><button onClick="adicionarVitoria(${index})">Vitória</button></td>
        <td><button onClick="adicionarEmpate(${index})">Empate</button></td>
        <td><button onClick="adicionarDerrota(${index})">Derrota</button></td>
        <td><button onClick="reiniciar(${index})">Reiniciar</button></td>
        <td><button onClick="removeJogador(${index})">Remover Jogador</buton onClick></td>
      </tr>
`;
}

function adicionarJogador() {
  var nomeNovoJogador = document.getElementById("nomeJogador").value;
  jogadores.push({
    nome: nomeNovoJogador,
    vitoria: 0,
    empate: 0,
    derrotas: 0,
    pontos: 0
  });
  document.getElementById("nomeJogador").value = "";
  exibirNaTela();
}

function adicionarVitoria(index) {
  jogadores[index].vitoria++;
  jogadores[index].pontos = jogadores[index].pontos + 3;
  exibirNaTela();
}

function adicionarEmpate(index) {
  jogadores[index].empate++;
  jogadores[index].pontos++;
  exibirNaTela();
}

function adicionarDerrota(index) {
  jogadores[index].derrotas++;
  exibirNaTela();
}

function reiniciar(index) {
  jogadores[index].vitoria = 0;
  jogadores[index].empate = 0;
  jogadores[index].derrotas = 0;
  jogadores[index].pontos = 0;
  exibirNaTela();
}
function removeJogador(index) {
  jogadores.splice(index, 1);
  exibirNaTela();
}

function removerTodos() {
  jogadores = [];
  exibirNaTela();
}
//background-color: #111
//https://www.hdcarwallpapers.com/walls/mercedes_amg_f1_w12_e_performance_4k_9-HD.jpg
//var txtNome = document.getElementById("nomeJogador")
var nomeNovoJogador = document.getElementById("nomeJogador");
// attaching keyup event to textBox
nomeNovoJogador.addEventListener("keyup", (e) => {
  e.preventDefault();
  if (e.keyCode === 13) {
    enviar.click(); // triggering click if `keycode === 13`
  }
});
