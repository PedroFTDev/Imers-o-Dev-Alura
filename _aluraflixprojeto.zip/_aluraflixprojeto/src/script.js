var ListaSeries = ["https://i.pinimg.com/564x/ef/65/da/ef65dab2d6f7562a4245acada732ea4f.jpg", "https://i.pinimg.com/564x/44/44/b2/4444b2b8cb9464e952d37df7aec70cde.jpg", "https://upload.wikimedia.org/wikipedia/pt/thumb/7/71/Brooklyn_Nine-Nine-5.jpg/230px-Brooklyn_Nine-Nine-5.jpg", "https://i.pinimg.com/564x/f3/f1/bb/f3f1bbdbb24c8c2796fe8322159b2827.jpg", "https://i.pinimg.com/564x/ba/d4/f9/bad4f9994c06cb192fe19f141dfc7ecb.jpg", "https://p2.trrsf.com/image/fget/cf/1200/1600/middle/images.terra.com/2022/11/25/unnamed-1ib3894cp3hwm.jpg", ];

var NomeSeries = ["Outer Banks", "Harry Potter And The Goblet of Fire", "B99", "Suits", "Arrow", "Harry Potter: CS"];


var i = 0;

document.write('<div class="container_todasSeries">');

while (i < ListaSeries.length) 
{
  if (ListaSeries[i].endsWith("jpg")) 
  {
      document.write('<div class="series">');
      document.write("<img src=" + ListaSeries[i] + ">");
      document.write('<p class="nomesSeries">' + NomeSeries[i] + "</p>");
      document.write("</div>");
  }
  i++;
}