# _AluraFlix - Projeto

A Pen created on CodePen.io. Original URL: [https://codepen.io/PedroT-Dev/pen/XWByZMy](https://codepen.io/PedroT-Dev/pen/XWByZMy).

